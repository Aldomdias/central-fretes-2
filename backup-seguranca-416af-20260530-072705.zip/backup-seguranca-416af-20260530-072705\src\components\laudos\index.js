export { LaudoNegociacaoTemplate } from './LaudoNegociacaoTemplate';
